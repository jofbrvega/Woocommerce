<header class="header-site">
    <nav class="header-nav">
        <div class="nav-row"> <?php wp_nav_menu(array('theme_location' => 'primary',)) ?> </div>
    </nav>
    <h1 class="red"> <?php echo get_bloginfo('name'); ?> </h1>
</header>